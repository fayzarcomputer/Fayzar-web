/**
 * Fayzar Job AutoFill - Background Service Worker (Manifest V3)
 * Handles Context Menus, State Sync, and Profile Counting Badges
 */

// Initialize defaults on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(['fayzar_profiles', 'fayzar_settings'], (res) => {
    if (!res.fayzar_profiles) {
      // Seed an example candidate profile for immediate demonstration
      const defaultProfiles = [
        {
          id: 'prof_demo_1',
          name: 'মো: আব্দুর রহিম (অফিস সহকারী ডেমো)',
          updatedAt: new Date().toISOString(),
          semanticMap: {
            applicant_name: 'MD. ABDUR RAHIM',
            applicant_name_bn: 'মো: আব্দুর রহিম',
            father_name: 'MD. ABDUL KARIM',
            father_name_bn: 'মো: আব্দুল করিম',
            mother_name: 'RAHIMA BEGUM',
            mother_name_bn: 'রহিমা বেগম',
            dob_full: '1998-05-15',
            dob_day: '15',
            dob_month: '05',
            dob_year: '1998',
            gender: 'Male',
            nid_no: '19982715698000123',
            marital_status: 'Single',
            religion: 'Islam',
            blood_group: 'B+',
            quota: 'Non-Quota',
            mobile_no: '01717101919',
            confirm_mobile: '01717101919',
            email_address: 'rahim.fayzar@gmail.com',

            // Present Address
            present_care_of: 'MD. ABDUL KARIM',
            present_village: 'College Road, Phulbari',
            present_district: 'Dinajpur',
            present_upazila: 'Phulbari',
            present_post_office: 'Phulbari',
            present_post_code: '5260',
            same_as_present: true,

            // Permanent Address
            permanent_care_of: 'MD. ABDUL KARIM',
            permanent_village: 'College Road, Phulbari',
            permanent_district: 'Dinajpur',
            permanent_upazila: 'Phulbari',
            permanent_post_office: 'Phulbari',
            permanent_post_code: '5260',

            // SSC
            ssc_exam: 'S.S.C',
            ssc_board: 'Dinajpur',
            ssc_roll: '154820',
            ssc_reg: '1215487920',
            ssc_result: 'Passed',
            ssc_gpa: '4.85',
            ssc_group: 'Science',
            ssc_year: '2014',

            // HSC
            hsc_exam: 'H.S.C',
            hsc_board: 'Dinajpur',
            hsc_roll: '102540',
            hsc_reg: '1215487920',
            hsc_result: 'Passed',
            hsc_gpa: '4.50',
            hsc_group: 'Science',
            hsc_year: '2016',

            // Graduation
            grad_exam: 'Honours',
            grad_institute: 'National University',
            grad_subject: 'Political Science',
            grad_result: 'Passed',
            grad_cgpa: '3.25',
            grad_year: '2020',
            grad_duration: '4'
          }
        }
      ];
      chrome.storage.local.set({ fayzar_profiles: defaultProfiles });
      updateBadge(defaultProfiles.length);
    } else {
      updateBadge(res.fayzar_profiles.length);
    }

    if (!res.fayzar_settings) {
      chrome.storage.local.set({
        fayzar_settings: {
          serverSyncUrl: 'http://localhost:3000/api/save-profiles',
          autoHighlight: true,
          activeProfileId: 'prof_demo_1'
        }
      });
    }
  });

  // Create Context Menus for Right Click
  chrome.contextMenus.create({
    id: 'fayzar_root',
    title: '⚡ ফয়জার জব অটো-ফিল (Fayzar AutoFill)',
    contexts: ['page', 'editable']
  });

  chrome.contextMenus.create({
    id: 'fayzar_autofill',
    parentId: 'fayzar_root',
    title: '✨ ১-ক্লিকে ফর্ম পূরণ করুন (Auto-Fill)',
    contexts: ['page', 'editable']
  });

  chrome.contextMenus.create({
    id: 'fayzar_capture',
    parentId: 'fayzar_root',
    title: '💾 এই ফর্মের তথ্য সেভ করুন (Capture Form)',
    contexts: ['page', 'editable']
  });
});

// Update Badge count on extension icon
function updateBadge(count) {
  if (count > 0) {
    chrome.action.setBadgeText({ text: String(count) });
    chrome.action.setBadgeBackgroundColor({ color: '#059669' }); // Emerald green
  } else {
    chrome.action.setBadgeText({ text: '' });
  }
}

// Handle Context Menu Clicks
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab || !tab.id) return;

  if (info.menuItemId === 'fayzar_autofill') {
    chrome.storage.local.get(['fayzar_profiles', 'fayzar_settings'], (res) => {
      const profiles = res.fayzar_profiles || [];
      const settings = res.fayzar_settings || {};
      const activeId = settings.activeProfileId;
      const targetProfile = profiles.find(p => p.id === activeId) || profiles[0];

      if (!targetProfile) {
        chrome.notifications?.create({
          type: 'basic',
          iconUrl: 'icons/icon48.png',
          title: 'ফয়জার জব অটো-ফিল',
          message: 'কোনো প্রার্থী প্রোফাইল পাওয়া যায়নি! অনুগ্রহ করে প্রোফাইল তৈরি করুন।'
        });
        return;
      }

      chrome.tabs.sendMessage(tab.id, {
        action: 'AUTOFILL_FORM',
        profileData: targetProfile
      }, (response) => {
        if (chrome.runtime.lastError) {
          console.warn('AutoFill tab error:', chrome.runtime.lastError.message);
        }
      });
    });
  }

  if (info.menuItemId === 'fayzar_capture') {
    chrome.tabs.sendMessage(tab.id, { action: 'CAPTURE_FORM' }, (response) => {
      if (chrome.runtime.lastError || !response) return;

      const profileName = (tab.title || 'অনলাইন ফর্ম') + ' - ' + new Date().toLocaleDateString('bn-BD');
      const newProfile = {
        id: 'prof_' + Date.now(),
        name: profileName,
        updatedAt: new Date().toISOString(),
        url: tab.url,
        semanticMap: response.semanticMap,
        fields: response.fields
      };

      chrome.storage.local.get(['fayzar_profiles'], (data) => {
        const list = data.fayzar_profiles || [];
        list.unshift(newProfile);
        chrome.storage.local.set({ fayzar_profiles: list }, () => {
          updateBadge(list.length);
        });
      });
    });
  }
});

// -------------------------------------------------------------
// Live Auto-Update Checker from fayzarcomputer.com
// -------------------------------------------------------------
const CURRENT_VERSION = '2.0.0';
const UPDATE_CHECK_URL = 'https://fayzarcomputer.com/version.json';

async function checkRemoteUpdate() {
  try {
    const res = await fetch(UPDATE_CHECK_URL, { cache: 'no-cache' });
    if (!res.ok) return;
    const data = await res.json();
    if (data && data.version && data.version !== CURRENT_VERSION) {
      chrome.action.setBadgeText({ text: 'NEW' });
      chrome.action.setBadgeBackgroundColor({ color: '#10b981' });
      chrome.storage.local.set({
        fayzar_update_available: {
          latestVersion: data.version,
          notes: data.notes || '',
          updateUrl: data.updateUrl || 'https://fayzarcomputer.com/portal.html'
        }
      });
    }
  } catch (err) {
    // Fail silently when offline
  }
}

chrome.runtime.onStartup.addListener(checkRemoteUpdate);
checkRemoteUpdate();

