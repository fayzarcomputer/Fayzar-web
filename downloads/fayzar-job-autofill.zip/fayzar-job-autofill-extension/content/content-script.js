/**
 * Fayzar Job AutoFill - Content Script Engine
 * Handles 1-Click Form Capture and 1-Click Auto-Fill Injection
 */

(function() {
  // Prevent duplicate injection if already initialized
  if (window.__FAYZAR_AUTOFILL_INJECTED__ && window.FayzarAutoFill) return;
  window.__FAYZAR_AUTOFILL_INJECTED__ = true;

  function hasBangla(str) {
    return /[\u0980-\u09FF]/.test(String(str || ''));
  }
  function hasEnglish(str) {
    return /[a-zA-Z]/.test(String(str || ''));
  }

  // Visual highlight styles for filled fields
  const styleEl = document.createElement('style');
  styleEl.textContent = `
    .fayzar-autofill-highlight {
      outline: 2px solid #10b981 !important;
      background-color: #ecfdf5 !important;
      transition: all 0.3s ease !important;
    }
    .fayzar-autofill-pulse {
      animation: fayzarPulse 1.2s ease;
    }
    @keyframes fayzarPulse {
      0% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7); }
      70% { box-shadow: 0 0 0 10px rgba(16, 185, 129, 0); }
      100% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); }
    }
  `;
  document.head.appendChild(styleEl);

  // Trigger input, change and blur events so JavaScript/framework validations accept the injected value
  function triggerEvents(el) {
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
  }

  // Base64 to File Injection using standard browser DataTransfer API
  function attachBase64ToFileInput(inputElement, base64Data, fileName) {
    if (!inputElement || !base64Data) return false;
    try {
      const parts = base64Data.split(',');
      const byteCharacters = atob(parts[1] || parts[0]);
      const byteArrays = [];
      for (let offset = 0; offset < byteCharacters.length; offset += 512) {
        const slice = byteCharacters.slice(offset, offset + 512);
        const byteNumbers = new Array(slice.length);
        for (let i = 0; i < slice.length; i++) {
          byteNumbers[i] = slice.charCodeAt(i);
        }
        byteArrays.push(new Uint8Array(byteNumbers));
      }
      const blob = new Blob(byteArrays, { type: 'image/jpeg' });
      const file = new File([blob], fileName, { type: 'image/jpeg' });
      const dt = new DataTransfer();
      dt.items.add(file);
      inputElement.files = dt.files;
      inputElement.dispatchEvent(new Event('change', { bubbles: true }));
      inputElement.dispatchEvent(new Event('input', { bubbles: true }));
      return true;
    } catch (err) {
      console.warn('Fayzar AutoFill: File attachment error:', err);
      return false;
    }
  }

  function showFloatingMediaIndicator(message) {
    let box = document.getElementById('fayzar-floating-alert');
    if (!box) {
      box = document.createElement('div');
      box.id = 'fayzar-floating-alert';
      box.style.cssText = 'position:fixed;bottom:20px;right:20px;z-index:999999;background:#064e3b;color:#ecfdf5;border:1px solid #10b981;padding:10px 16px;border-radius:12px;box-shadow:0 10px 25px rgba(0,0,0,0.3);font-family:sans-serif;font-size:12px;font-weight:bold;display:flex;align-items:center;gap:8px;transition:all 0.3s;';
      document.body.appendChild(box);
    }
    box.textContent = message;
    box.style.opacity = '1';
    setTimeout(() => {
      box.style.opacity = '0';
      setTimeout(() => box.remove(), 400);
    }, 3500);
  }

  // -------------------------------------------------------------
  // 1. CAPTURE FORM DATA (RoboForm style)
  // -------------------------------------------------------------
  function captureCurrentForm() {
    const inputs = Array.from(document.querySelectorAll('input, select, textarea'));
    const capturedFields = [];
    const semanticMap = {};

    inputs.forEach(el => {
      // Skip passwords, buttons, submits, hidden tokens
      if (['submit', 'button', 'reset', 'password', 'image'].includes(el.type)) return;
      if (el.type === 'hidden' && (el.name.includes('token') || el.name.includes('csrf') || el.value.length > 50)) return;

      const semanticKey = window.FayzarDOM ? window.FayzarDOM.detectFieldKey(el) : (el.name || el.id);
      const label = window.FayzarDOM ? window.FayzarDOM.getElementLabelText(el) : '';
      const selector = window.FayzarDOM ? window.FayzarDOM.generateSelector(el) : (el.id ? `#${el.id}` : el.name);

      let val = el.value;
      let checked = el.checked;

      if (el.tagName === 'SELECT') {
        val = el.value;
        const selectedOpt = el.options[el.selectedIndex];
        capturedFields.push({
          tag: 'select',
          name: el.name,
          id: el.id,
          selector,
          semanticKey,
          label,
          value: val,
          text: selectedOpt ? selectedOpt.text.trim() : ''
        });
        if (val) semanticMap[semanticKey] = val;
      } else if (el.type === 'radio') {
        if (checked) {
          capturedFields.push({
            tag: 'input',
            type: 'radio',
            name: el.name,
            id: el.id,
            selector,
            semanticKey,
            label,
            value: val,
            checked: true
          });
          semanticMap[semanticKey] = val;
        }
      } else if (el.type === 'checkbox') {
        capturedFields.push({
          tag: 'input',
          type: 'checkbox',
          name: el.name,
          id: el.id,
          selector,
          semanticKey,
          label,
          checked
        });
        semanticMap[semanticKey] = checked;
      } else {
        // Text, email, tel, number, date, textarea
        capturedFields.push({
          tag: el.tagName.toLowerCase(),
          type: el.type,
          name: el.name,
          id: el.id,
          selector,
          semanticKey,
          label,
          value: val
        });
        if (val) semanticMap[semanticKey] = val;
      }
    });

    return {
      success: true,
      url: window.location.href,
      pageTitle: document.title,
      capturedAt: new Date().toISOString(),
      fieldsCount: capturedFields.length,
      filledCount: Object.keys(semanticMap).length,
      fields: capturedFields,
      semanticMap: semanticMap
    };
  }

  // -------------------------------------------------------------
  // 2. AUTO-FILL FORM (RoboForm style)
  // -------------------------------------------------------------
  function autoFillForm(profileData) {
    if (!profileData) return { success: false, error: 'কোনো প্রোফাইল ডেটা পাওয়া যায়নি' };

    // Clone semanticMap to avoid modifying caller's state directly
    const semanticMap = Object.assign({}, profileData.semanticMap || profileData);
    const explicitFields = profileData.fields || [];
    const inputs = Array.from(document.querySelectorAll('input, select, textarea'));

    // ── Self-healing & Normalization of English vs Bengali Names ────────
    // If an older profile stored Bengali name in applicant_name, recover the true
    // English name and Bengali name separately using explicitFields:
    const nameConfigs = [
      { enKey: 'applicant_name', bnKey: 'applicant_name_bn', fieldNames: ['name', 'applicant_name', 'p_name'], bnFieldNames: ['name_bn', 'applicant_name_bn', 'b_name'] },
      { enKey: 'father_name', bnKey: 'father_name_bn', fieldNames: ['father', 'father_name', 'f_name'], bnFieldNames: ['father_bn', 'father_name_bn', 'f_name_bn'] },
      { enKey: 'mother_name', bnKey: 'mother_name_bn', fieldNames: ['mother', 'mother_name', 'm_name'], bnFieldNames: ['mother_bn', 'mother_name_bn', 'm_name_bn'] },
      { enKey: 'spouse_name', bnKey: 'spouse_name_bn', fieldNames: ['spouse', 'spouse_name'], bnFieldNames: ['spouse_bn', 'spouse_name_bn'] }
    ];

    nameConfigs.forEach(cfg => {
      let curEnVal = semanticMap[cfg.enKey] || '';
      let curBnVal = semanticMap[cfg.bnKey] || '';

      // If English key currently holds a Bengali value
      if (hasBangla(curEnVal)) {
        if (!curBnVal || !hasBangla(curBnVal)) {
          semanticMap[cfg.bnKey] = curEnVal; // move Bengali value to _bn key
        }
        // Now find true English value from explicitFields
        const enField = explicitFields.find(f => 
          (cfg.fieldNames.includes(f.name) || cfg.fieldNames.includes(f.id)) &&
          hasEnglish(f.value) && !hasBangla(f.value)
        );
        if (enField) {
          semanticMap[cfg.enKey] = enField.value;
        } else {
          // Look in other candidate fields or clear it so it doesn't paste Bengali into English
          const altEnField = explicitFields.find(f => 
            (f.name && (f.name.includes(cfg.fieldNames[0]) || f.id.includes(cfg.fieldNames[0]))) &&
            !f.name.includes('bn') && !f.id.includes('bn') &&
            hasEnglish(f.value) && !hasBangla(f.value)
          );
          if (altEnField) {
            semanticMap[cfg.enKey] = altEnField.value;
          }
        }
      }

      // If _bn key is empty, check explicitFields for Bengali field
      if (!semanticMap[cfg.bnKey]) {
        const bnField = explicitFields.find(f => 
          (cfg.bnFieldNames.includes(f.name) || cfg.bnFieldNames.includes(f.id)) &&
          hasBangla(f.value)
        );
        if (bnField) {
          semanticMap[cfg.bnKey] = bnField.value;
        }
      }
    });

    let filledCount = 0;
    let mediaAttachedCount = 0;

    // -------------------------------------------------------------
    // ATTACH PHOTO & SIGNATURE TO FILE INPUTS (Teletalk & BD Forms)
    // -------------------------------------------------------------
    const fileInputs = Array.from(document.querySelectorAll('input[type="file"]'));
    fileInputs.forEach(fileInput => {
      const name = (fileInput.name || '').toLowerCase();
      const id = (fileInput.id || '').toLowerCase();
      const label = (window.FayzarDOM ? window.FayzarDOM.getElementLabelText(fileInput) : '').toLowerCase();
      const combined = `${name} ${id} ${label}`;

      // Photo Detection (photo, pic, picture, image, ছবি)
      if (profileData.photoBase64 && (combined.includes('photo') || combined.includes('pic') || combined.includes('image') || combined.includes('ছবি') || combined.includes('picture') || (!name && !id))) {
        const attached = attachBase64ToFileInput(fileInput, profileData.photoBase64, 'applicant_photo_300x300.jpg');
        if (attached) {
          highlightElement(fileInput);
          mediaAttachedCount++;
        }
      }

      // Signature Detection (signature, sign, স্বাক্ষর)
      if (profileData.signatureBase64 && (combined.includes('signature') || combined.includes('sign') || combined.includes('স্বাক্ষর'))) {
        const attached = attachBase64ToFileInput(fileInput, profileData.signatureBase64, 'applicant_signature_300x80.jpg');
        if (attached) {
          highlightElement(fileInput);
          mediaAttachedCount++;
        }
      }
    });

    inputs.forEach(el => {
      if (['submit', 'button', 'reset', 'password', 'image', 'file'].includes(el.type)) return;

      const semanticKey = window.FayzarDOM ? window.FayzarDOM.detectFieldKey(el) : (el.name || el.id);

      // Determine what value to inject
      let targetValue = undefined;

      // 1. Direct match by semantic key
      if (semanticMap[semanticKey] !== undefined && semanticMap[semanticKey] !== '') {
        targetValue = semanticMap[semanticKey];
      }

      // 2. Match by exact selector, name or ID from explicit fields
      if (targetValue === undefined && explicitFields.length > 0) {
        const found = explicitFields.find(f => 
          (f.id && f.id === el.id) || 
          (f.name && f.name === el.name) ||
          (f.semanticKey === semanticKey)
        );
        if (found) {
          targetValue = found.value !== undefined ? found.value : found.text;
        }
      }

      // ── Language Safety Guard ─────────────────────────────────────────
      // Ensure English fields NEVER receive Bengali, and Bengali fields receive Bengali
      const isEnglishNameField = ['applicant_name', 'father_name', 'mother_name', 'spouse_name'].includes(semanticKey);
      const isBengaliNameField = ['applicant_name_bn', 'father_name_bn', 'mother_name_bn', 'spouse_name_bn'].includes(semanticKey);

      if (isEnglishNameField) {
        // If targetValue contains Bengali characters, it's incorrect for an English field!
        if (hasBangla(targetValue)) {
          // Look for an English alternative in explicitFields
          const enAlt = explicitFields.find(f =>
            (f.name === el.name || f.id === el.id || f.semanticKey === semanticKey) &&
            hasEnglish(f.value) && !hasBangla(f.value)
          );
          if (enAlt) {
            targetValue = enAlt.value;
          } else {
            // Do not fill Bengali into English name field
            targetValue = undefined;
          }
        }
      } else if (isBengaliNameField) {
        // If targetValue has only English and no Bengali, look for Bengali value
        if (hasEnglish(targetValue) && !hasBangla(targetValue)) {
          const bnAlt = explicitFields.find(f =>
            (f.name === el.name || f.id === el.id || f.name === el.name + '_bn' || f.id === el.id + '_bn' || f.semanticKey === semanticKey) &&
            hasBangla(f.value)
          );
          if (bnAlt) {
            targetValue = bnAlt.value;
          }
        }
      }

      if (targetValue === undefined || targetValue === null || targetValue === '') return;

      // Handle Select Element
      if (el.tagName === 'SELECT') {
        const targetStr = String(targetValue).trim().toLowerCase();
        let matchedIndex = -1;

        // Try exact value match
        for (let i = 0; i < el.options.length; i++) {
          if (el.options[i].value.trim().toLowerCase() === targetStr) {
            matchedIndex = i;
            break;
          }
        }

        // Try matching option text
        if (matchedIndex === -1) {
          for (let i = 0; i < el.options.length; i++) {
            const optText = el.options[i].text.trim().toLowerCase();
            if (optText === targetStr || optText.includes(targetStr) || targetStr.includes(optText)) {
              matchedIndex = i;
              break;
            }
          }
        }

        if (matchedIndex !== -1) {
          el.selectedIndex = matchedIndex;
          triggerEvents(el);
          highlightElement(el);
          filledCount++;
        }
      } 
      // Handle Radio Button
      else if (el.type === 'radio') {
        const valStr = String(targetValue).trim().toLowerCase();
        const elValStr = el.value.trim().toLowerCase();
        const labelStr = (window.FayzarDOM ? window.FayzarDOM.getElementLabelText(el) : '').toLowerCase();

        if (elValStr === valStr || labelStr.includes(valStr) || valStr.includes(elValStr)) {
          el.checked = true;
          triggerEvents(el);
          highlightElement(el);
          filledCount++;
        }
      } 
      // Handle Checkbox
      else if (el.type === 'checkbox') {
        const shouldCheck = Boolean(targetValue === true || targetValue === 'true' || targetValue === '1' || targetValue === 'yes');
        el.checked = shouldCheck;
        triggerEvents(el);
        highlightElement(el);
        filledCount++;
      } 
      // Handle Text, Number, Tel, Email, Date, Textarea
      else {
        el.value = targetValue;
        triggerEvents(el);
        highlightElement(el);
        filledCount++;
      }
    });

    if (mediaAttachedCount > 0) {
      showFloatingMediaIndicator(`📷 ছবি ও স্বাক্ষর সংযুক্ত হয়েছে (${mediaAttachedCount}টি)`);
    }

    return {
      success: true,
      filledCount,
      mediaAttachedCount,
      totalFields: inputs.length
    };
  }

  function highlightElement(el) {
    el.classList.add('fayzar-autofill-highlight', 'fayzar-autofill-pulse');
    setTimeout(() => {
      el.classList.remove('fayzar-autofill-pulse');
      setTimeout(() => {
        el.classList.remove('fayzar-autofill-highlight');
      }, 2500);
    }, 1200);
  }

  // Expose to window for direct calls
  window.FayzarAutoFill = {
    captureCurrentForm,
    autoFillForm
  };

  // Custom DOM event listener for in-page triggers
  window.addEventListener('fayzar_autofill_event', (e) => {
    if (e.detail) {
      autoFillForm(e.detail);
    }
  });

  // -------------------------------------------------------------
  // 3. MESSAGE LISTENER
  // -------------------------------------------------------------
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.action === 'CAPTURE_FORM') {
        const result = captureCurrentForm();
        sendResponse(result);
        return true;
      }

      if (request.action === 'AUTOFILL_FORM') {
        const result = autoFillForm(request.profileData);
        sendResponse(result);
        return true;
      }

      if (request.action === 'PING') {
        sendResponse({ status: 'PONG', title: document.title, url: window.location.href });
        return true;
      }
    });
  }

})();
