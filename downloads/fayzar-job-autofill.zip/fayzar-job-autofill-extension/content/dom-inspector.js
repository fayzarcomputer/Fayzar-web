/**
 * Fayzar Job AutoFill - DOM Inspector & Field Normalizer
 * Specialized for Bangladesh Job Application Portals (Teletalk, Gov, Bank & General Jobs)
 */

window.FayzarDOM = (function() {
  function hasBangla(str) {
    return /[\u0980-\u09FF]/.test(String(str || ''));
  }
  function hasEnglish(str) {
    return /[a-zA-Z]/.test(String(str || ''));
  }

  // Regex Dictionary for BD Job Forms
  const FIELD_DICTIONARY = [
    // Personal Info
    { key: 'dob_day', patterns: [/dob.*day/i, /birth.*day/i, /^day$/i, /দিন/i] },
    { key: 'dob_month', patterns: [/dob.*month/i, /birth.*month/i, /^month$/i, /মাস/i] },
    { key: 'dob_year', patterns: [/dob.*year/i, /birth.*year/i, /^year$/i, /বছর/i] },
    { key: 'dob_full', patterns: [/date.*of.*birth/i, /^dob$/i, /birth.*date/i, /জন্মতারিখ/i, /জন্ম\s*তারিখ/i] },
    { key: 'gender', patterns: [/gender/i, /sex/i, /লিঙ্গ/i] },
    { key: 'nid_no', patterns: [/nid/i, /national.*id/i, /জাতীয়\s*পরিচয়পত্র/i, /এনআইডি/i] },
    { key: 'brc_no', patterns: [/birth.*reg/i, /brc/i, /জন্ম\s*নিবন্ধন/i] },
    { key: 'marital_status', patterns: [/marital/i, /marriage/i, /বৈবাহিক\s*অবস্থা/i] },
    { key: 'religion', patterns: [/religion/i, /ধর্ম/i] },
    { key: 'blood_group', patterns: [/blood/i, /রক্তের\s*গ্রুপ/i] },
    { key: 'quota', patterns: [/quota/i, /কোটা/i, /freedom.*fighter/i, /মুক্তিযোদ্ধা/i] },
    { key: 'mobile_no', patterns: [/mobile/i, /phone/i, /contact_?no/i, /মোবাইল/i, /ফোন/i] },
    { key: 'confirm_mobile', patterns: [/confirm.*mobile/i, /re.*mobile/i, /মোবাইল.*পুনরায়/i] },
    { key: 'email_address', patterns: [/email/i, /e-mail/i, /ইমেইল/i] },

    // Present Address
    { key: 'present_care_of', patterns: [/present.*care/i, /pr_care/i, /care.*of/i, /অভিভাবক/i, /প্রযোজ্য/i] },
    { key: 'present_village', patterns: [/present.*village/i, /pr_vill/i, /present.*road/i, /present.*flat/i, /গ্রাম/i, /রাস্তা/i] },
    { key: 'present_district', patterns: [/present.*dist/i, /pr_dist/i, /বর্তমান.*জেলা/i, /জেলা/i] },
    { key: 'present_upazila', patterns: [/present.*upa/i, /present.*thana/i, /pr_thana/i, /উপজেলা/i, /থানা/i] },
    { key: 'present_post_office', patterns: [/present.*post.*office/i, /pr_po/i, /ডাকঘর/i] },
    { key: 'present_post_code', patterns: [/present.*post.*code/i, /pr_code/i, /পোস্ট\s*কোড/i] },
    { key: 'same_as_present', patterns: [/same.*as.*present/i, /chk.*same/i, /একই\s*ঠিকানা/i] },

    // Permanent Address
    { key: 'permanent_care_of', patterns: [/per.*care/i, /pm_care/i, /স্থায়ী.*অভিভাবক/i] },
    { key: 'permanent_village', patterns: [/per.*village/i, /pm_vill/i, /স্থায়ী.*গ্রাম/i] },
    { key: 'permanent_district', patterns: [/per.*dist/i, /pm_dist/i, /স্থায়ী.*জেলা/i] },
    { key: 'permanent_upazila', patterns: [/per.*upa/i, /per.*thana/i, /pm_thana/i, /স্থায়ী.*উপজেলা/i] },
    { key: 'permanent_post_office', patterns: [/per.*post.*office/i, /pm_po/i, /স্থায়ী.*ডাকঘর/i] },
    { key: 'permanent_post_code', patterns: [/per.*post.*code/i, /pm_code/i, /স্থায়ী.*পোস্ট\s*কোড/i] },

    // SSC Education
    { key: 'ssc_exam', patterns: [/ssc.*exam/i, /ssc.*type/i, /ssc_name/i, /এসএসসি.*পরীক্ষা/i] },
    { key: 'ssc_board', patterns: [/ssc.*board/i, /বোর্ড/i] },
    { key: 'ssc_roll', patterns: [/ssc.*roll/i, /রোল/i] },
    { key: 'ssc_reg', patterns: [/ssc.*reg/i, /রেজিস্ট্রেশন/i] },
    { key: 'ssc_result', patterns: [/ssc.*result/i, /ssc.*gpa/i, /জিপিএ/i, /ফলাফল/i] },
    { key: 'ssc_gpa', patterns: [/ssc.*gpa_?val/i, /ssc.*cgpa/i, /প্রাপ্ত\s*জিপিএ/i] },
    { key: 'ssc_group', patterns: [/ssc.*group/i, /ssc.*sub/i, /বিজ্ঞান/i, /মানবিক/i, /ব্যবসায়/i] },
    { key: 'ssc_year', patterns: [/ssc.*year/i, /ssc.*pass.*year/i, /পাসের\s*সাল/i] },

    // HSC Education
    { key: 'hsc_exam', patterns: [/hsc.*exam/i, /hsc.*type/i, /এইচএসসি/i] },
    { key: 'hsc_board', patterns: [/hsc.*board/i] },
    { key: 'hsc_roll', patterns: [/hsc.*roll/i] },
    { key: 'hsc_reg', patterns: [/hsc.*reg/i] },
    { key: 'hsc_result', patterns: [/hsc.*result/i, /hsc.*gpa/i] },
    { key: 'hsc_gpa', patterns: [/hsc.*gpa_?val/i, /hsc.*cgpa/i] },
    { key: 'hsc_group', patterns: [/hsc.*group/i, /hsc.*sub/i] },
    { key: 'hsc_year', patterns: [/hsc.*year/i, /hsc.*pass.*year/i] },

    // Graduation
    { key: 'grad_exam', patterns: [/gra.*exam/i, /deg.*exam/i, /hon.*exam/i, /স্নাতক/i, /ডিগ্রী/i, /অনার্স/i] },
    { key: 'grad_institute', patterns: [/gra.*inst/i, /gra.*univ/i, /বিশ্ববিদ্যালয়/i, /কলেজ/i] },
    { key: 'grad_subject', patterns: [/gra.*sub/i, /gra.*dept/i, /বিষয়/i] },
    { key: 'grad_result', patterns: [/gra.*res/i, /gra.*cgpa/i, /সিজিপিএ/i] },
    { key: 'grad_year', patterns: [/gra.*year/i, /gra.*pass.*year/i] },
    { key: 'grad_duration', patterns: [/gra.*dur/i, /course.*dur/i, /কোর্সের\s*মেয়াদ/i] },

    // Masters
    { key: 'masters_exam', patterns: [/mas.*exam/i, /মাস্টার্স/i, /স্নাতকোত্তর/i] },
    { key: 'masters_institute', patterns: [/mas.*inst/i, /mas.*univ/i] },
    { key: 'masters_subject', patterns: [/mas.*sub/i] },
    { key: 'masters_result', patterns: [/mas.*res/i, /mas.*cgpa/i] },
    { key: 'masters_year', patterns: [/mas.*year/i] }
  ];

  // Helper: Find associated label text for an element
  function getElementLabelText(el) {
    if (!el) return '';
    let labelText = '';

    // 1. Explicit <label for="id">
    if (el.id) {
      const label = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
      if (label) labelText += ' ' + label.textContent.trim();
    }

    // 2. Parent label
    const parentLabel = el.closest('label');
    if (parentLabel) labelText += ' ' + parentLabel.textContent.trim();

    // 3. Preceding sibling td/th in table row (Teletalk form layout)
    //    Only read the LABEL cell (previous sibling), NOT the input cell itself
    const td = el.closest('td, th');
    if (td) {
      // Previous cell in same row = the label cell
      if (td.previousElementSibling) {
        labelText += ' ' + td.previousElementSibling.textContent.trim();
      }
      // Also check the very first cell of the row (some Teletalk forms span columns)
      const tr = td.closest('tr');
      if (tr) {
        const firstCell = tr.firstElementChild;
        if (firstCell && firstCell !== td && firstCell !== td.previousElementSibling) {
          labelText += ' ' + firstCell.textContent.trim();
        }
      }
      // NOTE: Do NOT add td.textContent here — that is the INPUT cell, not the label!
    }

    // 4. Aria label or title or placeholder
    if (el.getAttribute('aria-label')) labelText += ' ' + el.getAttribute('aria-label');
    if (el.title) labelText += ' ' + el.title;
    if (el.placeholder) labelText += ' ' + el.placeholder;

    return labelText.replace(/\s+/g, ' ').trim();
  }

  // Identify semantic key for any form field
  function detectFieldKey(el) {
    const name = el.name || '';
    const id = el.id || '';
    const label = getElementLabelText(el);
    const combinedStr = `${name} ${id} ${label}`.toLowerCase();

    // ── 1. Specialized English vs Bengali Name Resolution ────────────
    // Forms like Teletalk and BD Gov have separate fields for English and Bengali names:
    // e.g. "Applicant's Name" vs "আবেদনকারীর নাম", "Father's Name" vs "পিতার নাম", etc.
    const isFather = /father|\bf_name\b|পিতা/.test(combinedStr);
    const isMother = /mother|\bm_name\b|মাতা/.test(combinedStr);
    const isSpouse = /spouse|husband|wife|স্বামী|স্ত্রী/.test(combinedStr);
    const isApplicant = !isFather && !isMother && !isSpouse && (/applicant|candidate|\bname\b|প্রার্থী|আবেদনকারী/.test(combinedStr));

    if (isFather || isMother || isSpouse || isApplicant) {
      const isExplicitBn = /_bn\b|b_name\b|bangla|বাংলা|বাংলায়/.test(combinedStr);
      const isExplicitEn = /_en\b|english|ইংরেজি/.test(combinedStr);
      const hasBnText = hasBangla(label);
      const hasEnText = hasEnglish(label);

      const baseKey = isFather ? 'father_name' : (isMother ? 'mother_name' : (isSpouse ? 'spouse_name' : 'applicant_name'));

      if (isExplicitBn && !isExplicitEn) return baseKey + '_bn';
      if (isExplicitEn && !isExplicitBn) return baseKey;
      if (name.includes('_bn') || id.includes('_bn')) return baseKey + '_bn';
      if (hasBnText && !hasEnText) return baseKey + '_bn';
      if (hasEnText && !hasBnText) return baseKey;
      return baseKey;
    }

    // ── 2. Standard Dictionary Matching ──────────────────────────────
    for (const item of FIELD_DICTIONARY) {
      for (const pattern of item.patterns) {
        if (pattern.test(combinedStr)) {
          return item.key;
        }
      }
    }

    // Fallback: return name or id or sanitized label
    return name || id || (label ? label.slice(0, 30).replace(/[^a-zA-Z0-9_\u0980-\u09FF]/g, '_') : 'unknown_field');
  }

  // Generate unique selector for an element
  function generateSelector(el) {
    if (el.id) return `#${CSS.escape(el.id)}`;
    if (el.name) {
      const tag = el.tagName.toLowerCase();
      const type = el.type ? `[type="${el.type}"]` : '';
      return `${tag}[name="${CSS.escape(el.name)}"]${type}`;
    }
    // Path fallback
    let path = [];
    let cur = el;
    while (cur && cur.nodeType === Node.ELEMENT_NODE && cur !== document.body) {
      let idx = 1;
      let sib = cur.previousElementSibling;
      while (sib) {
        if (sib.tagName === cur.tagName) idx++;
        sib = sib.previousElementSibling;
      }
      path.unshift(`${cur.tagName.toLowerCase()}:nth-of-type(${idx})`);
      cur = cur.parentElement;
    }
    return path.join(' > ');
  }

  return {
    detectFieldKey,
    getElementLabelText,
    generateSelector,
    hasBangla,
    hasEnglish
  };
})();
