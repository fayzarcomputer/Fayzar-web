/**
 * Fayzar Job AutoFill - Extension Popup Controller
 * Supports Cloud User Authentication, RoboForm-Style Multi-Files, and Photo/Signature Auto-Fill
 */

document.addEventListener('DOMContentLoaded', () => {
  // DOM Elements
  const authScreen = document.getElementById('auth-screen');
  const mainScreen = document.getElementById('main-screen');
  const userBar = document.getElementById('user-bar');
  const uMobile = document.getElementById('u-mobile');
  const btnUserLogout = document.getElementById('btn-user-logout');
  const btnAdminBypass = document.getElementById('btn-admin-bypass');

  const tabExtLogin = document.getElementById('tab-ext-login');
  const tabExtRegister = document.getElementById('tab-ext-register');
  const authName = document.getElementById('auth-name');
  const authMobile = document.getElementById('auth-mobile');
  const authPin = document.getElementById('auth-pin');
  const btnAuthSubmit = document.getElementById('btn-auth-submit');
  const btnAuthSubmitText = document.getElementById('btn-auth-submit-text');
  let authMode = 'login';

  tabExtLogin?.addEventListener('click', () => {
    authMode = 'login';
    tabExtLogin.style.background = 'var(--primary)';
    tabExtLogin.style.color = 'white';
    tabExtRegister.style.background = 'transparent';
    tabExtRegister.style.color = '#94a3b8';
    authName.classList.add('hidden');
    if (btnAuthSubmitText) btnAuthSubmitText.textContent = 'লগইন করুন';
  });

  tabExtRegister?.addEventListener('click', () => {
    authMode = 'register';
    tabExtRegister.style.background = 'var(--primary)';
    tabExtRegister.style.color = 'white';
    tabExtLogin.style.background = 'transparent';
    tabExtLogin.style.color = '#94a3b8';
    authName.classList.remove('hidden');
    if (btnAuthSubmitText) btnAuthSubmitText.textContent = 'নতুন অ্যাকাউন্ট তৈরি করুন';
  });

  const profileSelect = document.getElementById('profile-select');
  const countBadge = document.getElementById('profiles-count-badge');
  const syncIndicator = document.getElementById('sync-status-indicator');
  const previewBox = document.getElementById('profile-quick-preview');
  const prevName = document.getElementById('prev-name');
  const prevMobile = document.getElementById('prev-mobile');
  const prevNid = document.getElementById('prev-nid');
  const prevPhotoTag = document.getElementById('prev-photo-tag');
  const prevSigTag = document.getElementById('prev-sig-tag');

  const btnAutofill = document.getElementById('btn-autofill');
  const btnCapture = document.getElementById('btn-capture');
  const btnCloudSync = document.getElementById('btn-cloud-sync');
  const btnOpenManager = document.getElementById('btn-open-manager');
  const btnOpenPortal = document.getElementById('btn-open-portal');
  const btnTestPage = document.getElementById('btn-test-page');

  const statusAlert = document.getElementById('status-alert');
  const statusMessage = document.getElementById('status-message');
  const statusIcon = document.getElementById('status-icon');

  let currentCloudUser = null;
  let filesList = [];
  let activeFile = null;

  // 1. Show Status / Toast
  function showStatus(msg, isError = false) {
    statusMessage.textContent = msg;
    statusIcon.textContent = isError ? '✖' : '✔';
    statusAlert.className = `status-alert ${isError ? 'error' : ''}`;
    statusAlert.classList.remove('hidden');
    setTimeout(() => statusAlert.classList.add('hidden'), 3500);
  }

  // 2. Check Auth State
  function checkAuthState() {
    chrome.storage.local.get(['fayzar_cloud_user', 'fayzar_offline_mode'], (data) => {
      if (data.fayzar_cloud_user) {
        currentCloudUser = data.fayzar_cloud_user;
        authScreen.classList.add('hidden');
        mainScreen.classList.remove('hidden');
        userBar.classList.remove('hidden');
        uMobile.textContent = currentCloudUser.mobile;
        loadCloudUserFiles();
      } else if (data.fayzar_offline_mode) {
        authScreen.classList.add('hidden');
        mainScreen.classList.remove('hidden');
        userBar.classList.remove('hidden');
        uMobile.textContent = 'দোকান/অফলাইন মোড';
        loadLocalProfiles();
      } else {
        authScreen.classList.remove('hidden');
        mainScreen.classList.add('hidden');
        userBar.classList.add('hidden');
      }
    });
  }

  // 3. Login / Register
  btnAuthSubmit?.addEventListener('click', async () => {
    const mobile = authMobile.value.trim();
    const pin = authPin.value.trim();
    if (!mobile || !pin) {
      showStatus('মোবাইল নম্বর ও পিন লিখুন!', true);
      return;
    }

    btnAuthSubmit.disabled = true;
    btnAuthSubmit.textContent = 'যাচাই হচ্ছে...';

    try {
      const name = authName ? authName.value.trim() : '';
      const res = await FayzarFirebaseClient.registerOrLogin(mobile, pin, name);
      if (res.success) {
        currentCloudUser = res.user;
        chrome.storage.local.set({ 
          fayzar_cloud_user: currentCloudUser,
          fayzar_offline_mode: false 
        }, () => {
          checkAuthState();
          showStatus('লগইন সফল হয়েছে!');
        });
      } else {
        showStatus(res.error || 'লগইন ব্যর্থ হয়েছে!', true);
      }
    } catch (e) {
      showStatus('সার্ভার সমস্যা: ' + e.message, true);
    } finally {
      btnAuthSubmit.disabled = false;
      btnAuthSubmit.textContent = 'লগইন / ফাইল লোড করুন';
    }
  });

  // Admin / Offline Mode Bypass
  btnAdminBypass?.addEventListener('click', () => {
    chrome.storage.local.set({ fayzar_offline_mode: true }, () => {
      checkAuthState();
    });
  });

  // Logout
  btnUserLogout?.addEventListener('click', () => {
    chrome.storage.local.remove(['fayzar_cloud_user', 'fayzar_offline_mode'], () => {
      currentCloudUser = null;
      filesList = [];
      activeFile = null;
      checkAuthState();
    });
  });

  // 4. Load Files from Firebase
  async function loadCloudUserFiles() {
    if (!currentCloudUser) return;
    if (syncIndicator) syncIndicator.textContent = '🔄 সিঙ্ক হচ্ছে...';

    try {
      const res = await FayzarFirebaseClient.getUserFiles(currentCloudUser.mobile);
      if (res.success) {
        filesList = res.files || [];
        updateFilesUI('cloud');
      } else {
        // Fallback to local cache if offline
        loadLocalProfiles();
      }
    } catch (err) {
      loadLocalProfiles();
    }
  }

  function normalizeProfileNames(file) {
    if (!file || !file.semanticMap) return false;
    const sm = file.semanticMap;
    const fields = file.fields || [];
    let updated = false;

    const hasBangla = (s) => /[\u0980-\u09FF]/.test(String(s || ''));
    const hasEnglish = (s) => /[a-zA-Z]/.test(String(s || ''));

    const cfgs = [
      { enKey: 'applicant_name', bnKey: 'applicant_name_bn', fieldNames: ['name', 'applicant_name', 'p_name'] },
      { enKey: 'father_name', bnKey: 'father_name_bn', fieldNames: ['father', 'father_name', 'f_name'] },
      { enKey: 'mother_name', bnKey: 'mother_name_bn', fieldNames: ['mother', 'mother_name', 'm_name'] },
      { enKey: 'spouse_name', bnKey: 'spouse_name_bn', fieldNames: ['spouse', 'spouse_name'] }
    ];

    cfgs.forEach(c => {
      if (hasBangla(sm[c.enKey])) {
        if (!sm[c.bnKey] || !hasBangla(sm[c.bnKey])) {
          sm[c.bnKey] = sm[c.enKey];
        }
        const en = fields.find(f => c.fieldNames.includes(f.name) || c.fieldNames.includes(f.id));
        if (en && en.value && hasEnglish(en.value) && !hasBangla(en.value)) {
          sm[c.enKey] = en.value;
          updated = true;
        }
      }
    });

    return updated;
  }

  function loadLocalProfiles() {
    chrome.storage.local.get(['fayzar_profiles'], (data) => {
      filesList = data.fayzar_profiles || [];
      let anyUpdated = false;
      filesList.forEach(file => {
        if (normalizeProfileNames(file)) anyUpdated = true;
      });
      if (anyUpdated) {
        chrome.storage.local.set({ fayzar_profiles: filesList });
      }
      updateFilesUI('local');
    });
  }

  function updateFilesUI(source = 'cloud') {
    countBadge.textContent = `${filesList.length}টি`;
    if (syncIndicator) {
      syncIndicator.textContent = source === 'cloud' ? '🟢 ক্লাউড সিঙ্কড' : '💾 অফলাইন ফাইল';
    }

    if (filesList.length === 0) {
      profileSelect.innerHTML = '<option value="">-- কোনো ফাইল নেই --</option>';
      previewBox.classList.add('hidden');
      btnAutofill.disabled = true;
      btnAutofill.style.opacity = '0.6';
      return;
    }

    btnAutofill.disabled = false;
    btnAutofill.style.opacity = '1';

    profileSelect.innerHTML = filesList.map((f, i) => `
      <option value="${f.id || i}">${f.title || f.name || `ফাইল #${i + 1}`}</option>
    `).join('');

    activeFile = filesList[0];
    updatePreview(activeFile);
  }

  function updatePreview(file) {
    if (!file) {
      previewBox.classList.add('hidden');
      return;
    }

    const m = file.semanticMap || {};
    prevName.textContent = m.applicant_name || file.name || '-';
    prevMobile.textContent = m.mobile_no || currentCloudUser?.mobile || '-';
    prevNid.textContent = m.nid_no || '-';

    // Photo tag
    if (file.photoBase64) {
      prevPhotoTag.textContent = '📷 ছবি: সংযুক্ত ✓';
      prevPhotoTag.className = 'badge-media';
    } else {
      prevPhotoTag.textContent = '📷 ছবি: নেই';
      prevPhotoTag.className = 'badge-media none';
    }

    // Signature tag
    if (file.signatureBase64) {
      prevSigTag.textContent = '✍️ স্বাক্ষর: সংযুক্ত ✓';
      prevSigTag.className = 'badge-media';
    } else {
      prevSigTag.textContent = '✍️ স্বাক্ষর: নেই';
      prevSigTag.className = 'badge-media none';
    }

    previewBox.classList.remove('hidden');
  }

  profileSelect?.addEventListener('change', (e) => {
    activeFile = filesList.find(f => (f.id || '') === e.target.value) || filesList[0];
    updatePreview(activeFile);
  });

  // 5. Send Action to Current Tab (Direct In-Tab Execution for 100% Reliability)
  async function sendActionToTab(action, payload = null) {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tabs || tabs.length === 0) {
      showStatus('কোনো সক্রিয় ব্রাউজার ট্যাব পাওয়া যায়নি!', true);
      return;
    }
    const currentTab = tabs[0];

    // Check if target is a restricted chrome:// or edge:// url
    if (!currentTab.url || currentTab.url.startsWith('chrome://') || currentTab.url.startsWith('edge://')) {
      showStatus('ব্রাউজার সেটিংস পেজে অটো-ফিল কাজ করে না। কোনো চাকরির পেজে যান!', true);
      return;
    }

    try {
      // 1. Proactively inject DOM inspector & Content Script
      await chrome.scripting.executeScript({
        target: { tabId: currentTab.id },
        files: ['content/dom-inspector.js', 'content/content-script.js']
      });

      // 2. Direct In-Tab Execution (Bypasses message ports completely)
      if (action === 'autofill') {
        const results = await chrome.scripting.executeScript({
          target: { tabId: currentTab.id },
          func: (profile) => {
            if (window.FayzarAutoFill && window.FayzarAutoFill.autoFillForm) {
              return window.FayzarAutoFill.autoFillForm(profile);
            }
            return { success: false, error: 'AutoFill engine ready নয়' };
          },
          args: [payload]
        });

        const res = results && results[0] ? results[0].result : null;
        if (res && res.success) {
          const mediaMsg = res.mediaAttachedCount ? ` ও ${res.mediaAttachedCount}টি ফাইল` : '';
          showStatus(`সফল! ${res.filledCount}টি ফিল্ড${mediaMsg} পূরণ করা হয়েছে!`);
        } else {
          showStatus(res?.error || 'ফর্ম পূরণ করা সম্ভব হয়নি!', true);
        }
      } else if (action === 'capture') {
        const results = await chrome.scripting.executeScript({
          target: { tabId: currentTab.id },
          func: () => {
            if (window.FayzarAutoFill && window.FayzarAutoFill.captureCurrentForm) {
              return window.FayzarAutoFill.captureCurrentForm();
            }
            return { success: false, error: 'Capture engine ready নয়' };
          }
        });

        const res = results && results[0] ? results[0].result : null;
        const hasCapturedFields = res && (res.fieldsCount > 0 || (res.fields && res.fields.length > 0) || (res.semanticMap && Object.keys(res.semanticMap).length > 0));

        if (hasCapturedFields) {
          const filledCount = res.semanticMap ? Object.keys(res.semanticMap).length : res.fieldsCount;
          const candidateTitle = res.semanticMap?.applicant_name_bn || res.semanticMap?.applicant_name || 'আমার নতুন চাকরির আবেদন';
          const fileTitle = prompt('নতুন চাকরির ফাইলের একটি নাম দিন:', candidateTitle);
          if (!fileTitle) return;

          const newFile = {
            id: 'file_' + Date.now(),
            title: fileTitle,
            name: res.semanticMap?.applicant_name_bn || res.semanticMap?.applicant_name || fileTitle,
            semanticMap: res.semanticMap || {},
            fields: res.fields || [],
            photoBase64: activeFile?.photoBase64 || '',
            signatureBase64: activeFile?.signatureBase64 || ''
          };

          filesList.unshift(newFile);
          activeFile = newFile;

          if (currentCloudUser) {
            FayzarFirebaseClient.saveUserFile(currentCloudUser.mobile, newFile).then(() => {
              showStatus(`ফাইল ক্লাউডে সংরক্ষিত হয়েছে (${filledCount}টি ফিল্ড)!`);
              loadCloudUserFiles();
            });
          } else {
            chrome.storage.local.set({ fayzar_profiles: filesList }, () => {
              showStatus(`ফাইল অফলাইনে সংরক্ষিত হয়েছে (${filledCount}টি ফিল্ড)!`);
              loadLocalProfiles();
            });
          }
        } else {
          showStatus(res?.error || 'পেজে কোনো পূরণকৃত ফর্ম পাওয়া যায়নি!', true);
        }
      }
    } catch (err) {
      console.error('Execution error:', err);
      showStatus('ত্রুটি: ' + (err.message || err), true);
    }
  }

  // 6. 1-Click AutoFill
  btnAutofill?.addEventListener('click', () => {
    if (!activeFile) {
      showStatus('কোনো ফাইল নির্বাচিত নেই!', true);
      return;
    }
    showStatus('ফর্ম ও ছবি-স্বাক্ষর পূরণ হচ্ছে...');
    sendActionToTab('autofill', activeFile);
  });

  // 7. 1-Click Capture Form
  btnCapture?.addEventListener('click', () => {
    sendActionToTab('capture');
  });

  // 8. Manual Cloud Sync
  btnCloudSync?.addEventListener('click', () => {
    if (currentCloudUser) {
      showStatus('ক্লাউড থেকে ফাইল সিঙ্ক হচ্ছে...');
      loadCloudUserFiles().then(() => showStatus('ক্লাউড সিঙ্ক সম্পন্ন!'));
    } else {
      showStatus('লগইন না থাকায় অফলাইন ডেটা লোড করা হচ্ছে...');
      loadLocalProfiles();
    }
  });

  // 9. Quick Links
  btnOpenManager?.addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('manager/manager.html') });
  });

  btnOpenPortal?.addEventListener('click', () => {
    chrome.tabs.create({ url: 'http://localhost:3000/portal.html' });
  });

  btnTestPage?.addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('test-form.html') });
  });

  // Start Auth Check
  checkAuthState();
});
