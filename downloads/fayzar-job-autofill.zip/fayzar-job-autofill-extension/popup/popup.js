/**
 * Fayzar Job AutoFill - Extension Popup Controller
 * Supports Cloud User Authentication, RoboForm-Style Multi-Files, and Photo/Signature Auto-Fill
 */

document.addEventListener('DOMContentLoaded', () => {
  // DOM Elements
  const authScreen = document.getElementById('auth-screen');
  const mainScreen = document.getElementById('main-screen');
  const userBar = document.getElementById('user-bar');
  const uMobile = document.getElementById('u-mobile');
  const btnUserLogout = document.getElementById('btn-user-logout');
  const btnAdminBypass = document.getElementById('btn-admin-bypass');

  const tabExtLogin = document.getElementById('tab-ext-login');
  const tabExtRegister = document.getElementById('tab-ext-register');
  const authName = document.getElementById('auth-name');
  const authMobile = document.getElementById('auth-mobile');
  const authPin = document.getElementById('auth-pin');
  const btnAuthSubmit = document.getElementById('btn-auth-submit');
  const btnAuthSubmitText = document.getElementById('btn-auth-submit-text');
  let authMode = 'login';

  tabExtLogin?.addEventListener('click', () => {
    authMode = 'login';
    tabExtLogin.style.background = 'var(--primary)';
    tabExtLogin.style.color = 'white';
    tabExtRegister.style.background = 'transparent';
    tabExtRegister.style.color = '#94a3b8';
    authName.classList.add('hidden');
    if (btnAuthSubmitText) btnAuthSubmitText.textContent = 'লগইন করুন';
  });

  tabExtRegister?.addEventListener('click', () => {
    authMode = 'register';
    tabExtRegister.style.background = 'var(--primary)';
    tabExtRegister.style.color = 'white';
    tabExtLogin.style.background = 'transparent';
    tabExtLogin.style.color = '#94a3b8';
    authName.classList.remove('hidden');
    if (btnAuthSubmitText) btnAuthSubmitText.textContent = 'নতুন অ্যাকাউন্ট তৈরি করুন';
  });

  const profileSelect = document.getElementById('profile-select');
  const countBadge = document.getElementById('profiles-count-badge');
  const syncIndicator = document.getElementById('sync-status-indicator');
  const previewBox = document.getElementById('profile-quick-preview');
  const prevName = document.getElementById('prev-name');
  const prevMobile = document.getElementById('prev-mobile');
  const prevNid = document.getElementById('prev-nid');
  const prevPhotoTag = document.getElementById('prev-photo-tag');
  const prevSigTag = document.getElementById('prev-sig-tag');

  const btnAutofill = document.getElementById('btn-autofill');
  const btnCapture = document.getElementById('btn-capture');
  const btnCloudSync = document.getElementById('btn-cloud-sync');
  const btnOpenManager = document.getElementById('btn-open-manager');
  const btnOpenPortal = document.getElementById('btn-open-portal');
  const btnTestPage = document.getElementById('btn-test-page');

  const statusAlert = document.getElementById('status-alert');
  const statusMessage = document.getElementById('status-message');
  const statusIcon = document.getElementById('status-icon');

  let currentCloudUser = null;
  let filesList = [];
  let activeFile = null;

  // 1. Show Status / Toast
  function showStatus(msg, isError = false) {
    statusMessage.textContent = msg;
    statusIcon.textContent = isError ? '✖' : '✔';
    statusAlert.className = `status-alert ${isError ? 'error' : ''}`;
    statusAlert.classList.remove('hidden');
    setTimeout(() => statusAlert.classList.add('hidden'), 3500);
  }

  // 2. Check Auth State
  function checkAuthState() {
    chrome.storage.local.get(['fayzar_cloud_user', 'fayzar_offline_mode'], (data) => {
      if (data.fayzar_cloud_user) {
        currentCloudUser = data.fayzar_cloud_user;
        authScreen.classList.add('hidden');
        mainScreen.classList.remove('hidden');
        userBar.classList.remove('hidden');
        uMobile.textContent = currentCloudUser.mobile;
        loadCloudUserFiles();
      } else if (data.fayzar_offline_mode) {
        authScreen.classList.add('hidden');
        mainScreen.classList.remove('hidden');
        userBar.classList.remove('hidden');
        uMobile.textContent = 'দোকান/অফলাইন মোড';
        loadLocalProfiles();
      } else {
        authScreen.classList.remove('hidden');
        mainScreen.classList.add('hidden');
        userBar.classList.add('hidden');
      }
    });
  }

  // 3. Login / Register
  btnAuthSubmit?.addEventListener('click', async () => {
    const mobile = authMobile.value.trim();
    const pin = authPin.value.trim();
    if (!mobile || !pin) {
      showStatus('মোবাইল নম্বর ও পিন লিখুন!', true);
      return;
    }

    btnAuthSubmit.disabled = true;
    btnAuthSubmit.textContent = 'যাচাই হচ্ছে...';

    try {
      const name = authName ? authName.value.trim() : '';
      const res = await FayzarFirebaseClient.registerOrLogin(mobile, pin, name);
      if (res.success) {
        currentCloudUser = res.user;
        chrome.storage.local.set({ 
          fayzar_cloud_user: currentCloudUser,
          fayzar_offline_mode: false
        }, () => {
          checkAuthState();
          showStatus('লগইন সফল হয়েছে!');
        });
      } else {
        showStatus(res.error || 'লগইন ব্যর্থ হয়েছে!', true);
      }
    } catch (err) {
      showStatus('সার্ভার এরর: ' + err.message, true);
    } finally {
      btnAuthSubmit.disabled = false;
      btnAuthSubmit.textContent = authMode === 'login' ? 'লগইন করুন' : 'নতুন অ্যাকাউন্ট তৈরি করুন';
    }
  });

  // Offline / Store Mode Bypass
  btnAdminBypass?.addEventListener('click', () => {
    chrome.storage.local.set({ fayzar_offline_mode: true, fayzar_cloud_user: null }, () => {
      checkAuthState();
      showStatus('দোকান/অফলাইন মোড চালু হয়েছে');
    });
  });

  // Logout
  btnUserLogout?.addEventListener('click', () => {
    chrome.storage.local.remove(['fayzar_cloud_user', 'fayzar_offline_mode'], () => {
      currentCloudUser = null;
      checkAuthState();
      showStatus('লগআউট সম্পন্ন');
    });
  });

  // 4. Load Files (Cloud or Local)
  async function loadCloudUserFiles() {
    if (!currentCloudUser) return;
    syncIndicator.className = 'sync-dot active';
    syncIndicator.title = 'ক্লাউড সিঙ্কড';

    try {
      const files = await FayzarFirebaseClient.getUserFiles(currentCloudUser.mobile);
      if (files && files.length > 0) {
        filesList = files;
        chrome.storage.local.set({ fayzar_profiles: files });
      } else {
        // Fallback or seed default demo
        chrome.storage.local.get(['fayzar_profiles'], (d) => {
          filesList = d.fayzar_profiles || [
            {
              id: 'demo_1',
              title: currentCloudUser.name || 'আমার প্রাথমিক প্রোফাইল',
              name: currentCloudUser.name || 'মো: আব্দুর রহিম',
              semanticMap: {
                applicant_name: 'MD. ABDUR RAHIM',
                applicant_name_bn: currentCloudUser.name || 'মো: আব্দুর রহিম',
                mobile_no: currentCloudUser.mobile
              }
            }
          ];
        });
      }
      renderProfileSelect();
    } catch (err) {
      console.warn('Could not fetch cloud files, using local cache:', err);
      loadLocalProfiles();
    }
  }

  function loadLocalProfiles() {
    syncIndicator.className = 'sync-dot';
    syncIndicator.title = 'অফলাইন ডেটা';

    chrome.storage.local.get(['fayzar_profiles', 'fayzar_settings'], (data) => {
      filesList = data.fayzar_profiles || [];
      if (filesList.length === 0) {
        filesList = [
          {
            id: 'prof_demo_1',
            title: 'অফিস সহকারী ডেমো ফাইল',
            name: 'মো: আব্দুর রহিম',
            updatedAt: new Date().toISOString(),
            semanticMap: {
              applicant_name: 'MD. ABDUR RAHIM',
              applicant_name_bn: 'মো: আব্দুর রহিম',
              father_name: 'MD. ABDUL KARIM',
              father_name_bn: 'মো: আব্দুল করিম',
              mother_name: 'RAHIMA BEGUM',
              mother_name_bn: 'রহিমা বেগম',
              dob_full: '1998-05-15',
              dob_day: '15',
              dob_month: '05',
              dob_year: '1998',
              gender: 'Male',
              nid_no: '19982715698000123',
              marital_status: 'Single',
              religion: 'Islam',
              blood_group: 'B+',
              quota: 'Non-Quota',
              mobile_no: '01717101919',
              confirm_mobile: '01717101919',
              email_address: 'rahim.fayzar@gmail.com',
              present_care_of: 'MD. ABDUL KARIM',
              present_village: 'College Road, Phulbari',
              present_district: 'Dinajpur',
              present_upazila: 'Phulbari',
              present_post_office: 'Phulbari',
              present_post_code: '5260',
              same_as_present: true,
              permanent_care_of: 'MD. ABDUL KARIM',
              permanent_village: 'College Road, Phulbari',
              permanent_district: 'Dinajpur',
              permanent_upazila: 'Phulbari',
              permanent_post_office: 'Phulbari',
              permanent_post_code: '5260',
              ssc_exam: 'S.S.C',
              ssc_board: 'Dinajpur',
              ssc_roll: '154820',
              ssc_reg: '1215487920',
              ssc_result: 'Passed',
              ssc_gpa: '4.85',
              ssc_group: 'Science',
              ssc_year: '2014',
              hsc_exam: 'H.S.C',
              hsc_board: 'Dinajpur',
              hsc_roll: '102340',
              hsc_reg: '1215487920',
              hsc_result: 'Passed',
              hsc_gpa: '4.60',
              hsc_group: 'Science',
              hsc_year: '2016'
            }
          }
        ];
        chrome.storage.local.set({ fayzar_profiles: filesList });
      }
      renderProfileSelect();
    });
  }

  function renderProfileSelect() {
    profileSelect.innerHTML = '';
    countBadge.textContent = `${filesList.length}টি`;

    if (filesList.length === 0) {
      profileSelect.innerHTML = '<option value="">(কোনো ফাইল নেই)</option>';
      activeFile = null;
      updatePreview(null);
      return;
    }

    filesList.forEach((file, index) => {
      const opt = document.createElement('option');
      opt.value = file.id || String(index);
      const title = file.title || file.name || `ফাইল #${index + 1}`;
      opt.textContent = `${title}`;
      profileSelect.appendChild(opt);
    });

    activeFile = filesList[0];
    updatePreview(activeFile);
  }

  function updatePreview(file) {
    if (!file) {
      previewBox.classList.add('hidden');
      return;
    }

    const m = file.semanticMap || {};
    prevName.textContent = m.applicant_name || file.name || '-';
    prevMobile.textContent = m.mobile_no || currentCloudUser?.mobile || '-';
    prevNid.textContent = m.nid_no || '-';

    // Photo tag
    if (file.photoBase64) {
      prevPhotoTag.textContent = '📷 ছবি: সংযুক্ত ✓';
      prevPhotoTag.className = 'badge-media';
    } else {
      prevPhotoTag.textContent = '📷 ছবি: নেই';
      prevPhotoTag.className = 'badge-media none';
    }

    // Signature tag
    if (file.signatureBase64) {
      prevSigTag.textContent = '✍️ স্বাক্ষর: সংযুক্ত ✓';
      prevSigTag.className = 'badge-media';
    } else {
      prevSigTag.textContent = '✍️ স্বাক্ষর: নেই';
      prevSigTag.className = 'badge-media none';
    }

    previewBox.classList.remove('hidden');
  }

  profileSelect?.addEventListener('change', (e) => {
    activeFile = filesList.find(f => (f.id || '') === e.target.value) || filesList[0];
    updatePreview(activeFile);
  });

  // 5. Send Action to Current Tab (Hybrid: Message first for all pages including extension tabs, executeScript fallback for fresh web tabs)
  async function sendActionToTab(action, payload = null) {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tabs || tabs.length === 0) {
      showStatus('কোনো সক্রিয় ব্রাউজার ট্যাব পাওয়া যায়নি!', true);
      return;
    }
    const currentTab = tabs[0];

    // Check if target is a restricted chrome:// or edge:// url
    if (!currentTab.url || currentTab.url.startsWith('chrome://') || currentTab.url.startsWith('edge://')) {
      showStatus('ব্রাউজার সেটিংস পেজে অটো-ফিল কাজ করে না। কোনো চাকরির পেজে যান!', true);
      return;
    }

    const req = action === 'autofill'
      ? { action: 'AUTOFILL_FORM', profileData: payload }
      : { action: 'CAPTURE_FORM' };

    // Strategy 1: Try chrome.tabs.sendMessage (works on extension pages like test-form.html and loaded web pages)
    try {
      const response = await new Promise((resolve) => {
        chrome.tabs.sendMessage(currentTab.id, req, (res) => {
          if (chrome.runtime.lastError) {
            resolve(null);
          } else {
            resolve(res);
          }
        });
      });

      if (response && response.success) {
        if (action === 'autofill') {
          const mediaMsg = response.mediaAttachedCount ? ` ও ${response.mediaAttachedCount}টি ফাইল` : '';
          showStatus(`সফল! ${response.filledCount}টি ফিল্ড${mediaMsg} পূরণ করা হয়েছে!`);
        } else if (action === 'capture') {
          handleCapturedFormResponse(response);
        }
        return;
      }
    } catch (e) { }

    // Strategy 2: For regular web pages (http/https/file) where content script is not yet injected
    if (!currentTab.url.startsWith('chrome-extension://')) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId: currentTab.id },
          files: ['content/dom-inspector.js', 'content/content-script.js']
        });

        const results = await chrome.scripting.executeScript({
          target: { tabId: currentTab.id },
          func: (actionType, profile) => {
            if (actionType === 'autofill') {
              if (window.FayzarAutoFill && window.FayzarAutoFill.autoFillForm) {
                return window.FayzarAutoFill.autoFillForm(profile);
              }
            } else if (actionType === 'capture') {
              if (window.FayzarAutoFill && window.FayzarAutoFill.captureCurrentForm) {
                return window.FayzarAutoFill.captureCurrentForm();
              }
            }
            return { success: false, error: 'AutoFill engine ready নয়' };
          },
          args: [action, payload]
        });

        const res = results && results[0] ? results[0].result : null;
        if (res && res.success) {
          if (action === 'autofill') {
            const mediaMsg = res.mediaAttachedCount ? ` ও ${res.mediaAttachedCount}টি ফাইল` : '';
            showStatus(`সফল! ${res.filledCount}টি ফিল্ড${mediaMsg} পূরণ করা হয়েছে!`);
          } else if (action === 'capture') {
            handleCapturedFormResponse(res);
          }
          return;
        } else if (res && res.error) {
          showStatus(res.error, true);
          return;
        }
      } catch (err) {
        console.error('ExecuteScript error:', err);
        showStatus('ত্রুটি: ' + (err.message || err), true);
        return;
      }
    }

    showStatus('পেজে কোনো ফর্ম পাওয়া যায়নি অথবা পেজটি রিফ্রেশ করে আবার চেষ্টা করুন!', true);
  }

  function handleCapturedFormResponse(res) {
    const hasCapturedFields = res && (res.fieldsCount > 0 || (res.fields && res.fields.length > 0) || (res.semanticMap && Object.keys(res.semanticMap).length > 0));

    if (hasCapturedFields) {
      const filledCount = res.semanticMap ? Object.keys(res.semanticMap).length : res.fieldsCount;
      const candidateTitle = res.semanticMap?.applicant_name_bn || res.semanticMap?.applicant_name || 'আমার নতুন চাকরির আবেদন';
      const fileTitle = prompt('নতুন চাকরির ফাইলের একটি নাম দিন:', candidateTitle);
      if (!fileTitle) return;

      const newFile = {
        id: 'file_' + Date.now(),
        title: fileTitle,
        name: res.semanticMap?.applicant_name_bn || res.semanticMap?.applicant_name || fileTitle,
        semanticMap: res.semanticMap || {},
        fields: res.fields || [],
        photoBase64: activeFile?.photoBase64 || '',
        signatureBase64: activeFile?.signatureBase64 || ''
      };

      filesList.unshift(newFile);
      activeFile = newFile;

      if (currentCloudUser) {
        FayzarFirebaseClient.saveUserFile(currentCloudUser.mobile, newFile).then(() => {
          showStatus(`ফাইল ক্লাউডে সংরক্ষিত হয়েছে (${filledCount}টি ফিল্ড)!`);
          loadCloudUserFiles();
        });
      } else {
        chrome.storage.local.set({ fayzar_profiles: filesList }, () => {
          showStatus(`ফাইল অফলাইনে সংরক্ষিত হয়েছে (${filledCount}টি ফিল্ড)!`);
          loadLocalProfiles();
        });
      }
    } else {
      showStatus(res?.error || 'পেজে কোনো পূরণকৃত ফর্ম পাওয়া যায়নি!', true);
    }
  }

  // 6. 1-Click AutoFill
  btnAutofill?.addEventListener('click', () => {
    if (!activeFile) {
      showStatus('কোনো ফাইল নির্বাচিত নেই!', true);
      return;
    }
    showStatus('ফর্ম ও ছবি-স্বাক্ষর পূরণ হচ্ছে...');
    sendActionToTab('autofill', activeFile);
  });

  // 7. 1-Click Capture Form
  btnCapture?.addEventListener('click', () => {
    sendActionToTab('capture');
  });

  // 8. Manual Cloud Sync
  btnCloudSync?.addEventListener('click', () => {
    if (currentCloudUser) {
      showStatus('ক্লাউড থেকে ফাইল সিঙ্ক হচ্ছে...');
      loadCloudUserFiles().then(() => showStatus('ক্লাউড সিঙ্ক সম্পন্ন!'));
    } else {
      showStatus('লগইন না থাকায় অফলাইন ডেটা লোড করা হচ্ছে...');
      loadLocalProfiles();
    }
  });

  // 9. Quick Links
  btnOpenManager?.addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('manager/manager.html') });
  });

  btnOpenPortal?.addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://fayzarcomputer.github.io/portal.html' });
  });

  btnTestPage?.addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://fayzarcomputer.github.io/test-form.html' });
  });

  // Start Auth Check
  checkAuthState();
});
