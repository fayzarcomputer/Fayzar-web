/**
 * Fayzar Job AutoFill - Manager Controller Logic
 */

document.addEventListener('DOMContentLoaded', () => {
  const candidatesGrid = document.getElementById('candidates-grid');
  const searchInput = document.getElementById('search-candidates');
  const countDisplay = document.getElementById('total-candidates-count');

  const btnCreate = document.getElementById('btn-open-create-modal');
  const btnExport = document.getElementById('btn-export-backup');
  const inputImport = document.getElementById('input-import-backup');
  const btnCloudSync = document.getElementById('btn-cloud-sync');

  const modal = document.getElementById('candidate-modal');
  const modalTitle = document.getElementById('modal-title');
  const modalClose = document.getElementById('modal-close-btn');
  const btnCancel = document.getElementById('btn-cancel-modal');
  const form = document.getElementById('candidate-form');

  const sameAddressCheck = document.getElementById('m-same-address');
  const permanentBlock = document.getElementById('permanent-address-block');

  let profilesList = [];
  let activeProfileId = null;

  // Toggle same address
  sameAddressCheck?.addEventListener('change', () => {
    if (permanentBlock) {
      permanentBlock.style.display = sameAddressCheck.checked ? 'none' : 'block';
    }
  });

  // Modal Tabs Switching
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));

      btn.classList.add('active');
      const target = document.getElementById(btn.dataset.tab);
      if (target) target.classList.add('active');
    });
  });

  // Load Profiles
  function loadProfiles() {
    chrome.storage.local.get(['fayzar_profiles', 'fayzar_settings'], (data) => {
      profilesList = data.fayzar_profiles || [];
      const settings = data.fayzar_settings || {};
      activeProfileId = settings.activeProfileId;

      countDisplay.textContent = profilesList.length;
      renderGrid(searchInput.value);
    });
  }

  // Render Candidate Cards Grid
  function renderGrid(filterQuery = '') {
    const q = filterQuery.toLowerCase().trim();
    let filtered = profilesList;

    if (q) {
      filtered = filtered.filter(p => {
        const m = p.semanticMap || {};
        const combined = `${p.name} ${m.applicant_name} ${m.applicant_name_bn} ${m.mobile_no} ${m.nid_no}`.toLowerCase();
        return combined.includes(q);
      });
    }

    if (filtered.length === 0) {
      candidatesGrid.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; padding: 40px; background: var(--bg-card); border-radius: 16px; border: 1.5px dashed var(--border);">
          <h3 style="font-size: 16px; font-weight: 800; margin-bottom: 8px;">কোনো প্রার্থী প্রোফাইল পাওয়া যায়নি</h3>
          <p style="font-size: 12px; color: var(--text-muted); margin-bottom: 16px;">নতুন প্রার্থীর তথ্য যুক্ত করতে উপরের "নতুন প্রার্থী যোগ করুন" বোতামে চাপুন।</p>
          <button data-action="open-create" class="btn btn-primary">➕ প্রথম প্রার্থী যোগ করুন</button>
        </div>
      `;
      return;
    }

    candidatesGrid.innerHTML = filtered.map(p => {
      const m = p.semanticMap || {};
      const isActive = p.id === activeProfileId;

      return `
        <div class="candidate-card ${isActive ? 'active-profile-card' : ''}">
          <div>
            <div class="card-top">
              <div>
                <h3 class="card-title">${p.name}</h3>
                <div style="font-size: 11px; color: var(--primary); font-weight: 700; margin-top: 2px;">
                  ${m.applicant_name || '-'}
                </div>
              </div>
              <span class="card-badge">${isActive ? '⚡ সক্রিয় প্রার্থী' : 'সংরক্ষিত'}</span>
            </div>

            <div class="card-details">
              <div class="detail-row">
                <span>পিতার নাম:</span>
                <span>${m.father_name || m.father_name_bn || '-'}</span>
              </div>
              <div class="detail-row">
                <span>মোবাইল নম্বর:</span>
                <span style="color: var(--primary); font-family: monospace;">${m.mobile_no || '-'}</span>
              </div>
              <div class="detail-row">
                <span>জাতীয় পরিচয়পত্র:</span>
                <span style="font-family: monospace;">${m.nid_no || '-'}</span>
              </div>
              <div class="detail-row">
                <span>জন্মতারিখ:</span>
                <span>${m.dob_day ? `${m.dob_day}/${m.dob_month}/${m.dob_year}` : (m.dob_full || '-')}</span>
              </div>
              <div class="detail-row">
                <span>শিক্ষাগত যোগ্যতা:</span>
                <span>${m.grad_exam ? `${m.grad_exam} (${m.grad_subject || ''})` : (m.hsc_exam ? 'এইচএসসি' : (m.ssc_exam ? 'এসএসসি' : 'উল্লেখ নেই'))}</span>
              </div>
            </div>
          </div>

          <div class="card-actions">
            <div style="display: flex; gap: 6px;">
              ${!isActive ? `
                <button data-action="set-active" data-id="${p.id}" class="btn btn-sm btn-outline" style="color: var(--primary); border-color: var(--primary);">
                  সক্রিয় করুন
                </button>
              ` : `
                <span style="font-size: 11px; font-weight: 800; color: var(--primary);">সক্রিয় রয়েছে</span>
              `}
            </div>

            <div style="display: flex; gap: 6px;">
              <button data-action="edit" data-id="${p.id}" class="btn btn-sm btn-outline" title="তথ্য সম্পাদনা">
                ✏️ এডিট
              </button>
              <button data-action="delete" data-id="${p.id}" class="btn btn-sm btn-danger" title="মুছে ফেলুন">
                🗑️ ডিলিট
              </button>
            </div>
          </div>
        </div>
      `;
    }).join('');

    // Event delegation for CSP compliance (no inline onclick)
    candidatesGrid.querySelectorAll('button[data-action]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const action = btn.dataset.action;
        const id = btn.dataset.id;
        if (action === 'open-create') {
          document.getElementById('btn-open-create-modal')?.click();
        } else if (action === 'set-active' && id) {
          setActiveProfile(id);
        } else if (action === 'edit' && id) {
          editCandidate(id);
        } else if (action === 'delete' && id) {
          deleteCandidate(id);
        }
      });
    });
  }

  // Set Active Profile
  window.setActiveProfile = function(id) {
    chrome.storage.local.get(['fayzar_settings'], (res) => {
      const settings = res.fayzar_settings || {};
      settings.activeProfileId = id;
      chrome.storage.local.set({ fayzar_settings: settings }, () => {
        activeProfileId = id;
        loadProfiles();
      });
    });
  };

  // Delete Candidate
  window.deleteCandidate = function(id) {
    const p = profilesList.find(item => item.id === id);
    if (!p) return;

    if (confirm(`আপনি কি সত্যিই "${p.name}" প্রার্থীর সমস্ত তথ্য মুছে ফেলতে চান?`)) {
      profilesList = profilesList.filter(item => item.id !== id);
      chrome.storage.local.set({ fayzar_profiles: profilesList }, () => {
        chrome.storage.local.get(['fayzar_cloud_user'], (data) => {
          const u = data.fayzar_cloud_user;
          if (u && u.mobile && typeof FayzarFirebaseClient !== 'undefined') {
            FayzarFirebaseClient.deleteUserFile(u.mobile, id).catch(() => {});
          }
        });
        loadProfiles();
      });
    }
  };

  // Open Modal for Create
  btnCreate.addEventListener('click', () => {
    form.reset();
    document.getElementById('edit-profile-id').value = '';
    modalTitle.textContent = 'নতুন প্রার্থীর পূর্ণাঙ্গ তথ্য যোগ করুন';
    sameAddressCheck.checked = true;
    if (permanentBlock) permanentBlock.style.display = 'none';

    // Switch to first tab
    document.querySelectorAll('.tab-btn')[0].click();
    modal.classList.remove('hidden');
  });

  // Open Modal for Edit
  window.editCandidate = function(id) {
    const p = profilesList.find(item => item.id === id);
    if (!p) return;

    form.reset();
    document.getElementById('edit-profile-id').value = p.id;
    modalTitle.textContent = `প্রার্থীর তথ্য সম্পাদনা — ${p.name}`;

    const m = p.semanticMap || {};

    document.getElementById('m-profile-name').value = p.name || '';
    document.getElementById('m-applicant-name').value = m.applicant_name || '';
    document.getElementById('m-applicant-name-bn').value = m.applicant_name_bn || '';
    document.getElementById('m-father-name').value = m.father_name || '';
    document.getElementById('m-father-name-bn').value = m.father_name_bn || '';
    document.getElementById('m-mother-name').value = m.mother_name || '';
    document.getElementById('m-mother-name-bn').value = m.mother_name_bn || '';

    document.getElementById('m-dob-day').value = m.dob_day || '';
    document.getElementById('m-dob-month').value = m.dob_month || '';
    document.getElementById('m-dob-year').value = m.dob_year || '';

    document.getElementById('m-gender').value = m.gender || 'Male';
    document.getElementById('m-nid').value = m.nid_no || '';
    document.getElementById('m-brc').value = m.brc_no || '';
    document.getElementById('m-mobile').value = m.mobile_no || '';
    document.getElementById('m-email').value = m.email_address || '';
    document.getElementById('m-religion').value = m.religion || 'Islam';
    document.getElementById('m-blood').value = m.blood_group || 'B+';
    document.getElementById('m-marital').value = m.marital_status || 'Single';

    // Present Address
    document.getElementById('m-pr-care').value = m.present_care_of || '';
    document.getElementById('m-pr-village').value = m.present_village || '';
    document.getElementById('m-pr-dist').value = m.present_district || '';
    document.getElementById('m-pr-thana').value = m.present_upazila || '';
    document.getElementById('m-pr-po').value = m.present_post_office || '';
    document.getElementById('m-pr-code').value = m.present_post_code || '';

    // Permanent Address
    sameAddressCheck.checked = Boolean(m.same_as_present !== false);
    if (permanentBlock) permanentBlock.style.display = sameAddressCheck.checked ? 'none' : 'block';

    document.getElementById('m-pm-care').value = m.permanent_care_of || '';
    document.getElementById('m-pm-village').value = m.permanent_village || '';
    document.getElementById('m-pm-dist').value = m.permanent_district || '';
    document.getElementById('m-pm-thana').value = m.permanent_upazila || '';
    document.getElementById('m-pm-po').value = m.permanent_post_office || '';
    document.getElementById('m-pm-code').value = m.permanent_post_code || '';

    // SSC
    document.getElementById('m-ssc-exam').value = m.ssc_exam || 'S.S.C';
    document.getElementById('m-ssc-board').value = m.ssc_board || '';
    document.getElementById('m-ssc-group').value = m.ssc_group || '';
    document.getElementById('m-ssc-roll').value = m.ssc_roll || '';
    document.getElementById('m-ssc-reg').value = m.ssc_reg || '';
    document.getElementById('m-ssc-gpa').value = m.ssc_gpa || '';
    document.getElementById('m-ssc-year').value = m.ssc_year || '';

    // HSC
    document.getElementById('m-hsc-exam').value = m.hsc_exam || 'H.S.C';
    document.getElementById('m-hsc-board').value = m.hsc_board || '';
    document.getElementById('m-hsc-group').value = m.hsc_group || '';
    document.getElementById('m-hsc-roll').value = m.hsc_roll || '';
    document.getElementById('m-hsc-reg').value = m.hsc_reg || '';
    document.getElementById('m-hsc-gpa').value = m.hsc_gpa || '';
    document.getElementById('m-hsc-year').value = m.hsc_year || '';

    // Graduation
    document.getElementById('m-grad-exam').value = m.grad_exam || '';
    document.getElementById('m-grad-inst').value = m.grad_institute || '';
    document.getElementById('m-grad-sub').value = m.grad_subject || '';
    document.getElementById('m-grad-gpa').value = m.grad_result || m.grad_cgpa || '';
    document.getElementById('m-grad-year').value = m.grad_year || '';
    document.getElementById('m-grad-dur').value = m.grad_duration || '';

    // Quota
    document.getElementById('m-quota').value = m.quota || 'Non-Quota';
    document.getElementById('m-typing-en').value = m.typing_speed_en || '';
    document.getElementById('m-typing-bn').value = m.typing_speed_bn || '';
    document.getElementById('m-driving').value = m.driving_license || '';

    document.querySelectorAll('.tab-btn')[0].click();
    modal.classList.remove('hidden');
  };

  // Close modal
  function closeModal() {
    modal.classList.add('hidden');
  }

  modalClose.addEventListener('click', closeModal);
  btnCancel.addEventListener('click', closeModal);

  // Form Submit (Create / Update)
  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const editId = document.getElementById('edit-profile-id').value;
    const profileTitle = document.getElementById('m-profile-name').value.trim();

    const isSameAddress = sameAddressCheck.checked;
    const prCare = document.getElementById('m-pr-care').value.trim();
    const prVillage = document.getElementById('m-pr-village').value.trim();
    const prDist = document.getElementById('m-pr-dist').value.trim();
    const prThana = document.getElementById('m-pr-thana').value.trim();
    const prPo = document.getElementById('m-pr-po').value.trim();
    const prCode = document.getElementById('m-pr-code').value.trim();

    const semanticMap = {
      applicant_name: document.getElementById('m-applicant-name').value.trim(),
      applicant_name_bn: document.getElementById('m-applicant-name-bn').value.trim(),
      father_name: document.getElementById('m-father-name').value.trim(),
      father_name_bn: document.getElementById('m-father-name-bn').value.trim(),
      mother_name: document.getElementById('m-mother-name').value.trim(),
      mother_name_bn: document.getElementById('m-mother-name-bn').value.trim(),

      dob_day: document.getElementById('m-dob-day').value.trim(),
      dob_month: document.getElementById('m-dob-month').value.trim(),
      dob_year: document.getElementById('m-dob-year').value.trim(),
      dob_full: `${document.getElementById('m-dob-year').value.trim()}-${document.getElementById('m-dob-month').value.trim()}-${document.getElementById('m-dob-day').value.trim()}`,

      gender: document.getElementById('m-gender').value,
      nid_no: document.getElementById('m-nid').value.trim(),
      brc_no: document.getElementById('m-brc').value.trim(),
      mobile_no: document.getElementById('m-mobile').value.trim(),
      confirm_mobile: document.getElementById('m-mobile').value.trim(),
      email_address: document.getElementById('m-email').value.trim(),
      religion: document.getElementById('m-religion').value,
      blood_group: document.getElementById('m-blood').value,
      marital_status: document.getElementById('m-marital').value,

      // Address
      present_care_of: prCare,
      present_village: prVillage,
      present_district: prDist,
      present_upazila: prThana,
      present_post_office: prPo,
      present_post_code: prCode,
      same_as_present: isSameAddress,

      permanent_care_of: isSameAddress ? prCare : document.getElementById('m-pm-care').value.trim(),
      permanent_village: isSameAddress ? prVillage : document.getElementById('m-pm-village').value.trim(),
      permanent_district: isSameAddress ? prDist : document.getElementById('m-pm-dist').value.trim(),
      permanent_upazila: isSameAddress ? prThana : document.getElementById('m-pm-thana').value.trim(),
      permanent_post_office: isSameAddress ? prPo : document.getElementById('m-pm-po').value.trim(),
      permanent_post_code: isSameAddress ? prCode : document.getElementById('m-pm-code').value.trim(),

      // SSC
      ssc_exam: document.getElementById('m-ssc-exam').value.trim(),
      ssc_board: document.getElementById('m-ssc-board').value.trim(),
      ssc_group: document.getElementById('m-ssc-group').value.trim(),
      ssc_roll: document.getElementById('m-ssc-roll').value.trim(),
      ssc_reg: document.getElementById('m-ssc-reg').value.trim(),
      ssc_result: 'Passed',
      ssc_gpa: document.getElementById('m-ssc-gpa').value.trim(),
      ssc_year: document.getElementById('m-ssc-year').value.trim(),

      // HSC
      hsc_exam: document.getElementById('m-hsc-exam').value.trim(),
      hsc_board: document.getElementById('m-hsc-board').value.trim(),
      hsc_group: document.getElementById('m-hsc-group').value.trim(),
      hsc_roll: document.getElementById('m-hsc-roll').value.trim(),
      hsc_reg: document.getElementById('m-hsc-reg').value.trim(),
      hsc_result: 'Passed',
      hsc_gpa: document.getElementById('m-hsc-gpa').value.trim(),
      hsc_year: document.getElementById('m-hsc-year').value.trim(),

      // Graduation
      grad_exam: document.getElementById('m-grad-exam').value.trim(),
      grad_institute: document.getElementById('m-grad-inst').value.trim(),
      grad_subject: document.getElementById('m-grad-sub').value.trim(),
      grad_result: 'Passed',
      grad_cgpa: document.getElementById('m-grad-gpa').value.trim(),
      grad_year: document.getElementById('m-grad-year').value.trim(),
      grad_duration: document.getElementById('m-grad-dur').value.trim(),

      // Quota & Other
      quota: document.getElementById('m-quota').value,
      typing_speed_en: document.getElementById('m-typing-en').value.trim(),
      typing_speed_bn: document.getElementById('m-typing-bn').value.trim(),
      driving_license: document.getElementById('m-driving').value.trim()
    };

    if (editId) {
      // Update existing
      const idx = profilesList.findIndex(p => p.id === editId);
      if (idx !== -1) {
        profilesList[idx].name = profileTitle;
        profilesList[idx].updatedAt = new Date().toISOString();
        profilesList[idx].semanticMap = semanticMap;
      }
    } else {
      // Create new
      const newId = 'prof_' + Date.now();
      profilesList.unshift({
        id: newId,
        name: profileTitle,
        updatedAt: new Date().toISOString(),
        semanticMap: semanticMap
      });
      activeProfileId = newId;
    }

    chrome.storage.local.set({ fayzar_profiles: profilesList }, () => {
      // Also push to cloud (Firestore) so edits survive on all PCs
      chrome.storage.local.get(['fayzar_cloud_user'], (data) => {
        const u = data.fayzar_cloud_user;
        const savedFile = editId
          ? profilesList.find(p => p.id === editId)
          : profilesList.find(p => p.id === activeProfileId);
        if (u && u.mobile && savedFile && typeof FayzarFirebaseClient !== 'undefined') {
          FayzarFirebaseClient.saveUserFile(u.mobile, savedFile).then((res) => {
            if (res && res.success) {
              (editId ? closeModalAndSync() : closeModal());
              loadProfiles();
            } else {
              closeModal();
              loadProfiles();
            }
          }).catch(() => {
            closeModal();
            loadProfiles();
          });
        } else {
          closeModal();
          loadProfiles();
        }
      });
    });
  });

  function closeModalAndSync() {
    closeModal();
  }

  // Search Input Listener
  searchInput.addEventListener('input', () => {
    renderGrid(searchInput.value);
  });

  // Export Backup as JSON
  btnExport.addEventListener('click', () => {
    if (profilesList.length === 0) {
      alert('ডাউনলোড করার মতো কোনো প্রার্থীর তথ্য সংরক্ষিত নেই!');
      return;
    }

    const backupData = {
      app: 'Fayzar Job AutoFill',
      version: '1.0',
      exportedAt: new Date().toISOString(),
      count: profilesList.length,
      profiles: profilesList
    };

    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `fayzar_candidates_backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  });

  // Import Backup from JSON
  inputImport.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const imported = JSON.parse(event.target.result);
        const listToImport = imported.profiles || (Array.isArray(imported) ? imported : null);

        if (!listToImport || !Array.isArray(listToImport)) {
          alert('অবৈধ ব্যাকআপ ফাইল! সঠিক JSON ফাইল নির্বাচন করুন।');
          return;
        }

        if (confirm(`আপনি কি এই ফাইলের ${listToImport.length} জন প্রার্থীর তথ্য আপনার ডাটাবেজে যুক্ত করতে চান?`)) {
          // Merge avoiding duplicate IDs
          const existingIds = new Set(profilesList.map(p => p.id));
          listToImport.forEach(item => {
            if (existingIds.has(item.id)) {
              item.id = 'prof_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);
            }
            profilesList.unshift(item);
          });

          chrome.storage.local.set({ fayzar_profiles: profilesList }, () => {
            alert('ব্যাকআপ সফলভাবে রিস্টোর হয়েছে!');
            loadProfiles();
          });
        }
      } catch (err) {
        alert('JSON ফাইল পার্স করতে সমস্যা হয়েছে!');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  });

  // Cloud Sync Button in Manager
  btnCloudSync?.addEventListener('click', async () => {
    chrome.storage.local.get(['fayzar_cloud_user'], async (data) => {
      const u = data.fayzar_cloud_user;
      if (u && u.mobile && typeof FayzarFirebaseClient !== 'undefined') {
        btnCloudSync.disabled = true;
        btnCloudSync.textContent = 'সিঙ্ক হচ্ছে...';
        try {
          const res = await FayzarFirebaseClient.getUserFiles(u.mobile);
          const fetchedFiles = Array.isArray(res) ? res : (res?.files || []);
          if (fetchedFiles.length > 0) {
            profilesList = fetchedFiles;
            chrome.storage.local.set({ fayzar_profiles: profilesList }, () => {
              loadProfiles();
              alert(`ক্লাউড থেকে সফলভাবে ${profilesList.length}টি ফাইল সিঙ্ক হয়েছে!`);
            });
          } else {
            alert('ক্লাউডে এই অ্যাকাউন্টের কোনো অতিরিক্ত ফাইল পাওয়া যায়নি।');
          }
        } catch (err) {
          alert('ক্লাউড সিঙ্ক ত্রুটি: ' + err.message);
        } finally {
          btnCloudSync.disabled = false;
          btnCloudSync.textContent = '🔄 ক্লাউড সিঙ্ক';
        }
      } else {
        alert('ক্লাউড সিঙ্কের জন্য এক্সটেনশন পপআপ থেকে আপনার মোবাইল নম্বর ও পিন দিয়ে লগইন করুন।');
      }
    });
  });

  // Open edit modal directly when launched with ?edit=<id> (from popup)
  function openEditFromUrl() {
    const params = new URLSearchParams(window.location.search);
    const editId = params.get('edit');
    if (editId) {
      const p = profilesList.find(item => item.id === editId);
      if (p) {
        editCandidate(p.id);
      } else {
        setTimeout(() => {
          chrome.storage.local.get(['fayzar_profiles'], (data) => {
            profilesList = data.fayzar_profiles || [];
            if (profilesList.find(item => item.id === editId)) {
              editCandidate(editId);
            }
          });
        }, 400);
      }
    }
  }

  chrome.runtime?.onMessage?.addListener((msg) => {
    if (msg && msg.type === 'FAYZAR_OPEN_EDIT' && msg.fileId) {
      const p = profilesList.find(item => item.id === msg.fileId);
      if (p) editCandidate(p.id);
    }
  });

  // Initialize
  loadProfiles();
  openEditFromUrl();
});
